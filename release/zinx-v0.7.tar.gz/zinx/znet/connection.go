package znet

import (
	"errors"
	"fmt"
	"io"
	"net"
	"zinx/ziface"
)

// 连接模块
type Connection struct {
	// 连接套接字
	Conn *net.TCPConn

	// 连接ID
	ConnID uint32

	// 连接关闭状态
	isClosed bool

	//消息管理MsgId和对应处理方法的消息管理模块
	MsgHandler ziface.IMsgHandle

	//	告知连接关闭的 channel
	ExitBufChan chan bool

	//无缓冲管道，用于读、写两个goroutine之间的消息通信
	msgChan chan []byte
}

func (c *Connection) GetTCPConnection() *net.TCPConn {
	return c.Conn
}

func (c *Connection) RemoteAddr() net.Addr {
	return c.Conn.RemoteAddr()
}

// NewConnection 新建连接
func NewConnection(conn *net.TCPConn, connid uint32, msgHandle ziface.IMsgHandle) *Connection {
	return &Connection{
		Conn:        conn,
		ConnID:      connid,
		isClosed:    false,
		MsgHandler:  msgHandle,
		ExitBufChan: make(chan bool),
		msgChan:     make(chan []byte), //msgChan初始化
	}
}

// Start 启动连接
func (c *Connection) Start() {
	// 开启处理业务协程
	go c.StartReader()
	go c.StartWriter()

	for {
		select {
		case <-c.ExitBufChan:
			// 获得退出消息
			return
		}
	}
}

// StartReader 从连接中读取数据, 调用相应的的api
func (c *Connection) StartReader() {
	fmt.Println("Reader Goroutine is  running")
	defer fmt.Println(c.RemoteAddr().String(), " conn reader exit!")
	defer c.Stop()

	for {
		// 创建拆包解包的对象
		dp := NewDataPack()
		// 分为两次读操作: 读头部, 读消息内容
		headData := make([]byte, dp.GetHeadLen())
		_, err := io.ReadFull(c.Conn, headData)
		if err != nil {
			fmt.Println("read msg head error", err)
			c.ExitBufChan <- true
			continue
		}

		msg, err := dp.Unpack(headData)
		if err != nil {
			fmt.Println("unpack headData error", err)
			c.ExitBufChan <- true
			continue
		}

		//根据 dataLen 读取 data，放在msg.Data中
		var data []byte
		if msg.GetDataLen() > 0 {
			data = make([]byte, msg.GetDataLen())
			if _, err := io.ReadFull(c.Conn, data); err != nil {
				fmt.Println("read msg data error", err)
				c.ExitBufChan <- true
				continue
			}
		}
		msg.SetData(data)

		// 得到当前客户端请求的Request数据
		req := &Request{
			conn: c,
			msg:  msg,
		}
		//从路由 Routers 中找到注册绑定Conn的对应Handle
		go c.MsgHandler.DoMsgHandler(req)
	}
}

// StartWriter 写消息Goroutine， 用户将数据发送给客户端
func (c *Connection) StartWriter() {
	fmt.Println("[Writer Goroutine is running]")
	defer fmt.Println(c.RemoteAddr().String(), "[conn Writer exit!]")

	for {
		select {
		case data := <-c.msgChan:
			// 从管道中读取数据, 有数据要写给客户端
			if _, err := c.Conn.Write(data); err != nil {
				fmt.Println("Send Data error:, ", err, " Conn Writer exit")
				return
			}
		case <-c.ExitBufChan:
			return
		}
	}
}

// GetConnection 获取连接
func (c *Connection) GetConnection() *net.TCPConn {
	return c.Conn
}

// GetConnectionID 获取连接ID
func (c *Connection) GetConnectionID() uint32 {
	return c.ConnID
}

// GetConnectionAddr 获取客户段地址信息
func (c *Connection) GetConnectionAddr() net.Addr {
	return c.Conn.RemoteAddr()
}

// Stop 关闭连接
func (c *Connection) Stop() {
	if c.isClosed {
		return // 连接已经关闭
	}
	c.isClosed = true

	//TODO Connection Stop() 如果用户注册了该链接的关闭回调业务，那么在此刻应该显示调用

	c.Conn.Close()

	c.ExitBufChan <- true

	close(c.ExitBufChan)

}

// Send 发送数据
func (c *Connection) SendMsg(msgId uint32, data []byte) error {
	if c.isClosed {
		return errors.New("Connection closed when send msg")
	}
	dp := NewDataPack()
	pack, err := dp.Pack(NewMsgPackage(msgId, data))
	if err != nil {
		fmt.Println("Pack error msg id = ", msgId)
		return errors.New("Pack error msg ")
	}

	// 写回客户端
	c.msgChan <- pack   //将之前直接回写给conn.Write的方法 改为 发送给Channel 供Writer读取

	return nil
}
