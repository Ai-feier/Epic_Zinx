package ziface

import "net"

// IConnection 抽象连接模块
type IConnection interface {
	// Start 启动连接
	Start()

	// Stop Start停止链接
	Stop()

	// GetTCPConnection 获取连接的socket
	GetTCPConnection() *net.TCPConn

	// RemoteAddr 获取当前连接的ID
	RemoteAddr() net.Addr

	// 发送数据
	SendMsg(msgId uint32, data []byte) error
}

// 定义处理连接业务的方法
// 参数: tcp连接, 要处理的数据, 数据的长度
type HandleFunc func(*net.TCPConn, []byte, int) error
