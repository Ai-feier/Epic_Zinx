package znet

import (
	"errors"
	"fmt"
	"io"
	"net"
	"zinx/ziface"
)

// 连接模块
type Connection struct {
	// 连接套接字
	Conn *net.TCPConn

	// 连接ID
	ConnID uint32

	// 连接关闭状态
	isClosed bool

	//该连接的处理方法router
	Router  ziface.IRouter

	//	告知连接关闭的 channel
	ExitBufChan chan bool
}

func (c *Connection) GetTCPConnection() *net.TCPConn {
	return c.Conn
}

func (c *Connection) RemoteAddr() net.Addr {
	return c.Conn.RemoteAddr()
}

// 新建连接
func NewConnection(conn *net.TCPConn, connid uint32, router ziface.IRouter) *Connection {
	return &Connection{
		Conn: conn,
		ConnID: connid,
		isClosed: false,
		Router: router,
		ExitBufChan: make(chan bool),
	}
}

// 启动连接
func (c *Connection) Start() {
	// 开启处理业务协程
	go c.StartReader()

	for {
		select {
		case <- c.ExitBufChan:
			// 获得退出消息
			return
		}
	}
}

// StartReader 从连接中读取数据, 调用相应的的api
func (c *Connection) StartReader() {
	fmt.Println("Reader Goroutine is  running")
	defer fmt.Println(c.RemoteAddr().String(), " conn reader exit!")
	defer c.Stop()

	for {
		// 创建拆包解包的对象
		dp := NewDataPack()
		// 分为两次读操作: 读头部, 读消息内容
		headData := make([]byte, dp.GetHeadLen())
		_, err := io.ReadFull(c.Conn, headData)
		if err != nil {
			fmt.Println("read msg head error", err)
			c.ExitBufChan <- true
			continue
		}

		msg, err := dp.Unpack(headData)
		if err != nil {
			fmt.Println("unpack headData error", err)
			c.ExitBufChan <- true
			continue
		}

		//根据 dataLen 读取 data，放在msg.Data中
		var data []byte
		if msg.GetDataLen() > 0 {
			data = make([]byte, msg.GetDataLen())
			if _, err := io.ReadFull(c.Conn, data); err != nil {
				fmt.Println("read msg data error", err)
				c.ExitBufChan <- true
				continue
			}
		}
		msg.SetData(data)

		// 得到当前客户端请求的Request数据
		req := &Request{
			conn: c,
			msg: msg,
		}
		//从路由Routers 中找到注册绑定Conn的对应Handle
		go func(request ziface.IRequest) {
			// 执行注册路由
			c.Router.PreHandle(request)
			c.Router.Handle(request)
			c.Router.PostHandle(request)
		}(req)
	}
}



// 获取连接
func (c *Connection) GetConnection() *net.TCPConn {
	return c.Conn
}

// 获取连接ID
func (c *Connection) GetConnectionID() uint32 {
	return c.ConnID
}

// 获取客户段地址信息
func (c *Connection) GetConnectionAddr() net.Addr {
	return c.Conn.RemoteAddr()
}

// 关闭连接
func (c *Connection) Stop() {
	if c.isClosed {
		return  // 连接已经关闭
	}
	c.isClosed = true

	//TODO Connection Stop() 如果用户注册了该链接的关闭回调业务，那么在此刻应该显示调用

	c.Conn.Close()

	c.ExitBufChan <- true

	close(c.ExitBufChan)
	
}

// Send 发送数据
func (c *Connection) SendMsg(msgId uint32, data []byte) error {
	if c.isClosed {
		return errors.New("Connection closed when send msg")
	}
	dp := NewDataPack()
	pack, err := dp.Pack(&Message{
		DataLen: uint32(len(data)),
		ID:      msgId,
		Data:    data,
	})
	if err != nil {
		fmt.Println("Pack error msg id = ", msgId)
		return  errors.New("Pack error msg ")
	}

	// 写回客户端
	_, err = c.Conn.Write(pack)
	if err != nil {
		fmt.Println("Write msg id ", msgId, " error ")
		c.ExitBufChan <- true
		return errors.New("conn Write error")
	}
	return nil
}