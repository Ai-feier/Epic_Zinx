package znet

import (
	"fmt"
	"net"
	"zinx/ziface"
)

// Server IServer 的接口实现
type Server struct {
	// 服务器名称
	Name string
	// 服务器绑定 IP 的版本
	IPVersion string
	// 服务器监听的IP
	IP string
	// 服务器的端口
	Port int
}

// Start 启动服务器方法
func (s *Server) Start() {
	fmt.Printf("[START] Server listenner at IP: %s, Port %d, is starting\n", s.IP, s.Port)

	// 避免由于协程的阻塞上升到主线程阻塞的地步
	go func() {
		// 1. 获取 TCP 的 ADDR
		addr, err := net.ResolveTCPAddr(s.IPVersion, fmt.Sprintf("%s:%d", s.IP, s.Port))
		if err != nil {
			fmt.Println("resolve tcp addr error: ", err)
			return
		}

		// 2. 监听服务器地址
		listener, err := net.ListenTCP(s.IPVersion, addr)
		if err != nil {
			fmt.Println("listen ip addr error: ", err)
			return
		}

		fmt.Println("Start Zinx server success: ", s.Name, "Listening...")

		// 3. 阻塞等待客户端连接, 处理客户端连接的业务数据
		for {
			conn, err := listener.Accept()
			if err != nil {
				fmt.Println("Accept error: ", err)
				continue
			}

			// 基础实现: 回显输入
			go func() {
				for {
					buf := make([]byte, 512)
					cnt, err2 := conn.Read(buf)
					if err2 != nil {
						fmt.Println("conn io read error: ", err2)
						continue
					}

					fmt.Printf("recv client buf %s, count: %d\n", string(buf[:cnt]), cnt)

					// 读取成功后写回数据
					if _, err2 := conn.Write(buf[:cnt]); err2 != nil {
						fmt.Println("write buf error: ", err2)
						continue
					}
				}
			}()
		}
	}()
}

// Stop 停止服务器方法
func (s *Server) Stop() {
	//TODO 关闭服务器资源
}

// Serve 开启业务的方法
func (s *Server) Serve() {
	s.Start()

	// TODO 扩展额外业务

	// 阻塞线程
	select {}
}

// NewServer 初始化 Server
func NewServer(name string) ziface.IServer {
	return &Server{
		Name: name,
		IPVersion: "tcp4",
		IP: "0.0.0.0",
		Port: 8008,
	}
}