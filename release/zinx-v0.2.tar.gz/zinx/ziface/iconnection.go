package ziface

import "net"

// 抽象连接模块
type IConnection interface {
	// 启动连接
	Start()

	// 停止链接
	Stop()

	// 获取连接的socket
	GetTCPConnection() *net.TCPConn

	// 获取当前连接的ID
	RemoteAddr() *net.Addr

	// 发送数据
	Send(data []byte) error
}

// 定义处理连接业务的方法
// 参数: tcp连接, 要处理的数据, 数据的长度
type HandleFunc func(*net.TCPConn, []byte, int) error
