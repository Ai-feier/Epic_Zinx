package znet

import (
	"fmt"
	"net"
	"zinx/ziface"
)

// 连接模块
type Connection struct {
	// 连接套接字
	Conn *net.TCPConn

	// 连接ID
	ConnID uint32

	// 连接关闭状态
	isClosed bool

	// 连接所对应的处理方法
	handleApi ziface.HandleFunc

	//	告知连接关闭的 channel
	ExitBufChan chan bool
}

// 新建连接
func NewConnection(conn *net.TCPConn, connid uint32, handle ziface.HandleFunc) *Connection {
	return &Connection{
		Conn: conn,
		ConnID: connid,
		isClosed: false,
		handleApi: handle,
		ExitBufChan: make(chan bool),
	}
}

// 启动连接
func (c *Connection) Start() {
	// 开启处理业务协程
	go c.StartReader()

	for {
		select {
		case <- c.ExitBufChan:
			// 获得退出消息
			return
		}
	}
}

// 从连接中读取数据, 调用相应的的api
func (c *Connection) StartReader() {
	fmt.Println("connect start working...")
	defer fmt.Println("connection stop working...")
	defer c.Stop()

	for {
		buf := make([]byte, 512)
		cnt, err := c.Conn.Read(buf)
		if err != nil {
			fmt.Println("recv data err", err)
			c.ExitBufChan <- true
			continue
		}
		// 调用相应处理 API
		if err = c.handleApi(c.Conn, buf, cnt); err!= nil {
			fmt.Println("handle data error ", err)
			c.ExitBufChan <- true
			continue
		}
	}
}



// 获取连接
func (c *Connection) GetConnection() *net.TCPConn {
	return c.Conn
}

// 获取连接ID
func (c *Connection) GetConnectionID() uint32 {
	return c.ConnID
}

// 获取客户段地址信息
func (c *Connection) GetConnectionAddr() net.Addr {
	return c.Conn.RemoteAddr()
}

// 关闭连接
func (c *Connection) Stop() {
	if c.isClosed {
		return  // 连接已经关闭
	}
	c.isClosed = true

	//TODO Connection Stop() 如果用户注册了该链接的关闭回调业务，那么在此刻应该显示调用

	c.Conn.Close()

	c.ExitBufChan <- true

	close(c.ExitBufChan)
	
}